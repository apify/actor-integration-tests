<?php

echo "sourceType=TARBALL";