const Apify = require('apify');

Apify.main(async () => {
    console.log('sourceType=TARBALL');
});
