const { Actor } = require('apify');

Actor.main(async () => {
    console.log('sourceType=TARBALL');
});
